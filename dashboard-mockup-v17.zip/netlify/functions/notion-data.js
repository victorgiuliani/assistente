/**
 * Netlify Function — Apostas 2026 Dashboard.
 *
 * Lê do Notion ao vivo:
 *   - Performance Mensal 2026 (KPIs por mês)
 *   - Unidades por Tipster (matriz)
 *   - Databases mensais com cada aposta individual (Janeiro a Maio 2026)
 *
 * ENV VARS:
 *   - NOTION_TOKEN  → Internal Integration Secret
 *
 * Endpoint: GET /.netlify/functions/notion-data
 */

// API nova (2025-09-03) suporta databases multi-fonte via /data_sources/{id}/query
const NOTION_VERSION = '2025-09-03';

// IDs de DATA SOURCES (não databases) — usados pra contornar multi-source
const PERFORMANCE_DS = 'a0254645-ea53-4a85-b045-741411126ad9'; // Performance Mensal 2026
const UNIDADES_DS    = '3f464135-c5cf-4b89-a954-f583bde40543'; // Unidades por Tipster

// Mensais (data_source_id específico — só a fonte real de bets, ignorando "Nova fonte de dados" vazia)
const MONTHLY_DSS = [
  { mes: 'Jan', id: 'a3006620-4857-4e2f-9351-50dd1a50f84e' },
  { mes: 'Fev', id: 'ff64de5d-f36b-4e6e-9322-b148535a2489' },
  { mes: 'Mar', id: '31994954-b69f-45ed-b981-caedc72fe8ad' },
  { mes: 'Abr', id: '61223225-7bfe-411f-a615-c609f5fdae7c' },
  { mes: 'Mai', id: '7b474aae-2497-4155-81e8-c260f31b6f46' },
  { mes: 'Jun', id: '6efab8ae-991b-4e0b-9c27-12247eef5801' },
];

// Tipsters que nao seguem mais — escondidos do dashboard mesmo se ainda existem em Notion
// (apostas historicas continuam contando no total)
const HIDDEN_TIPSTERS = new Set([
  'FABIO GUILHERME VIP',
  'FABIO PROPS',
  'FABIO FREE',
  'ELITE DUNKS',
  'FABIO HOCKEY',
]);

const TIPSTER_COLORS = {
  'MORENO TIPS':       '#FFD60A',
  'SYRO NBA LIVE':     '#3b82f6',
  'VINI BASQUETE':     '#10b981',
  'WIZARDS TELEGRAM':  '#ec4899',
  'THEO BORGES':       '#06b6d4',
  'LUCAS FELIPE':      '#84cc16',
  'DANILO MARTINS':    '#94a3b8',
  'PUNTER BRASIL VIP': '#a78bfa',
  'VGIULIANI':         '#f97316',
  'DAVI STAKING':      '#ef4444',
  'OUTRO':             '#71717a',
};

const MESES = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];

/* ========== Notion API helpers ========== */

async function notionFetch(path, body){
  const r = await fetch(`https://api.notion.com/v1${path}`, {
    method: body ? 'POST' : 'GET',
    headers: {
      'Authorization': `Bearer ${process.env.NOTION_TOKEN}`,
      'Notion-Version': NOTION_VERSION,
      'Content-Type': 'application/json',
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if(!r.ok){
    const txt = await r.text();
    throw new Error(`Notion API ${r.status}: ${txt.slice(0,200)}`);
  }
  return r.json();
}

async function queryAllPages(dataSourceId){
  // API 2025-09-03: /v1/data_sources/{id}/query
  const all = [];
  let cursor;
  do {
    const data = await notionFetch(`/data_sources/${dataSourceId}/query`, {
      page_size: 100,
      ...(cursor ? {start_cursor: cursor} : {}),
    });
    all.push(...data.results);
    cursor = data.has_more ? data.next_cursor : null;
  } while(cursor);
  return all;
}

/* ========== Property helpers ========== */
const pTitle = p => p?.title?.[0]?.plain_text || null;
const pText  = p => p?.rich_text?.map(t => t.plain_text).join('') || null;
const pNum   = p => p?.number ?? null;
const pSel   = p => p?.select?.name || null;
const pDate  = p => p?.date?.start || null;

/* ========== Inferência de Esporte ========== */
function inferEsporte(competicao){
  if(!competicao) return 'Outros';
  const c = competicao.toUpperCase();
  if(/\bNBA\b|\bWNBA\b|BASQUETE|BASKETBALL|EUROL[EI]G|G-LEAGUE|NBB/.test(c)) return 'Basquete';
  if(/T[ÊE]NIS|\bATP\b|\bWTA\b|TENNIS/.test(c)) return 'Tênis';
  if(/V[ÔO]LEI|VOLLEY/.test(c)) return 'Vôlei';
  if(/MMA|\bUFC\b/.test(c)) return 'MMA';
  if(/E-?SPORTS?|\bCS\b|CSGO|CS2|\bLOL\b|DOTA|VALORANT/.test(c)) return 'E-Sports';
  if(/NFL|FUTEBOL AMERICANO/.test(c)) return 'Futebol Americano';
  if(/NHL|HOCKEY|HÓQUEI/.test(c)) return 'Hóquei';
  if(/MLB|BASEBALL|BEISEBOL/.test(c)) return 'Beisebol';
  // Default: Futebol (esmagadora maioria)
  return 'Futebol';
}

/* ========== Builders ========== */

function buildPerformanceMensal(rows){
  const map = {};
  rows.forEach(row => {
    const props = row.properties;
    const mes = pTitle(props['Mês']);
    if(!mes) return;
    map[mes] = {
      mes,
      ordem: pNum(props['Ordem']),
      profit: pNum(props['Profit']),
      stake: pNum(props['Stake']),
      picks: pNum(props['Picks']),
      win: pNum(props['Win']),
      lost: pNum(props['Lost']),
      void: pNum(props['Void']),
      pend: pNum(props['Pend']),
      yield: pNum(props['Yield']),
      odds: pNum(props['Odds']),
    };
  });
  return MESES.map((m,i) => map[m] || {
    mes:m, ordem:i+1, profit:null, stake:null, picks:null, win:null,
    lost:null, void:null, pend:null, yield:null, odds:null
  });
}

function buildUnidadesPorTipster(rows){
  const tipsters = rows.map(row => {
    const props = row.properties;
    const tipster = pTitle(props['Tipster']);
    if(!tipster) return null;
    if(HIDDEN_TIPSTERS.has(tipster)) return null;  // exclui tipsters arquivados
    const meses = {};
    MESES.forEach(m => {
      const v = pNum(props[m]);
      if(v !== null && v !== 0) meses[m] = v;
    });
    return {
      tipster,
      ordem: pNum(props['Ordem']) || 999,
      color: TIPSTER_COLORS[tipster] || '#94a3b8',
      meses,
    };
  }).filter(Boolean);
  tipsters.sort((a,b) => a.ordem - b.ordem);
  return tipsters;
}

function buildBets(monthlyResults){
  // monthlyResults: array de {mes, rows}
  const all = [];
  monthlyResults.forEach(({mes, rows}) => {
    rows.forEach(row => {
      const props = row.properties;
      const competicao = pText(props['Competição']);
      const esporte = inferEsporte(competicao);
      all.push({
        mes,
        data: pDate(props['Data']),
        tipster: pSel(props['Indicação']) || 'OUTRO',
        casa: pSel(props['Site']) || null,
        tipo: pSel(props['Tipo']) || null,
        resultado: pSel(props['Resultado']) || null,
        competicao,
        esporte,
        odds: pNum(props['Odds']),
        stake: pNum(props['Stake']),
        profit: pNum(props['Profit']),
        pick: pText(props['Pick']),
      });
    });
  });
  return all;
}

function disponivelDeBets(bets){
  const esportes = new Set();
  const casas = new Set();
  const tipos = new Set();
  bets.forEach(b => {
    if(b.esporte) esportes.add(b.esporte);
    if(b.casa) casas.add(b.casa);
    if(b.tipo) tipos.add(b.tipo);
  });
  const sortByCount = (set) => [...set].sort();
  return {
    esportes: sortByCount(esportes),
    casas: sortByCount(casas),
    tipos: sortByCount(tipos),
  };
}

function computeAviso(perfMensal, tipsters){
  const perfTotal = perfMensal.reduce((s,m)=>s+(m.profit||0), 0);
  const tipsterTotal = tipsters.reduce((s,t)=>{
    return s + Object.values(t.meses).reduce((ss,v)=>ss+v, 0);
  }, 0);
  const diff = Math.abs(perfTotal - tipsterTotal);
  if(diff < 0.5) return null;
  return `Performance Mensal e Unidades por Tipster nao batem 100% no Notion (${perfTotal.toFixed(2)}u vs ${tipsterTotal.toFixed(2)}u). Com filtros granulares, os calculos vem das apostas individuais (fonte de verdade).`;
}

/* ========== Handler ========== */

exports.handler = async () => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
  };

  if(!process.env.NOTION_TOKEN){
    return {
      statusCode: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'NOTION_TOKEN não configurado' }),
    };
  }

  try {
    const t0 = Date.now();

    // Tudo em paralelo: aggregadas + 5 mensais
    const [perfRows, unidadesRows, ...monthlyRowsPairs] = await Promise.all([
      queryAllPages(PERFORMANCE_DS),
      queryAllPages(UNIDADES_DS),
      ...MONTHLY_DSS.map(async ({mes, id}) => ({mes, rows: await queryAllPages(id)})),
    ]);

    const performanceMensal = buildPerformanceMensal(perfRows);
    const unidadesPorTipster = buildUnidadesPorTipster(unidadesRows);
    const bets = buildBets(monthlyRowsPairs);
    const disponivel = disponivelDeBets(bets);

    // Aviso só faz sentido quando dashboard NÃO tem bets como fonte de verdade.
    // Em modo "ao vivo" com bets, o dashboard calcula tudo das apostas individuais
    // (fonte de verdade), entao a divergencia entre PM e Unidades nao afeta o dashboard.
    const aviso = bets.length > 0 ? null : computeAviso(performanceMensal, unidadesPorTipster);

    // Horário de Brasília
    const agoraBR = new Intl.DateTimeFormat('pt-BR', {
      timeZone: 'America/Sao_Paulo',
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit',
      hour12: false,
    }).format(new Date()).replace(',', '');

    const result = {
      geradoEm: agoraBR,
      fonte: 'Notion · Apostas 2026 (ao vivo)',
      aviso,
      config: { bancaInicial: 50000, valorPorUnidade: 100 },
      performanceMensal,
      unidadesPorTipster,
      bets,
      disponivel,
      _debug: {
        durationMs: Date.now() - t0,
        perfRows: perfRows.length,
        unidadesRows: unidadesRows.length,
        bets: bets.length,
        monthlyBreakdown: monthlyRowsPairs.map(p => ({mes:p.mes, count:p.rows.length})),
      },
    };

    return {
      statusCode: 200,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json',
        'Cache-Control': 'public, max-age=60, s-maxage=60, stale-while-revalidate=300',
      },
      body: JSON.stringify(result),
    };
  } catch(e) {
    return {
      statusCode: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: 'Erro consultando Notion',
        message: e.message,
      }),
    };
  }
};
