# 📊 Apostas 2026 · Dashboard

Dashboard com integração **ao vivo ao Notion** via Netlify Function (com fallback pra snapshot estático).

## 📁 Estrutura

```
dashboard-mockup/
├── index.html                            ← dashboard (HTML+CSS+JS, com data embutido como fallback)
├── data.json                             ← snapshot dos dados (fallback se a function falhar)
├── netlify.toml                          ← config do Netlify (functions, headers, redirects)
├── netlify/
│   └── functions/
│       └── notion-data.js                ← serverless function que puxa do Notion ao vivo
└── README.md
```

## 🟢 Como o site escolhe os dados (cascata de fallback)

Toda vez que alguém abre o site, ele tenta nesta ordem:

1. **`/.netlify/functions/notion-data`** → ao vivo do Notion (badge verde "● AO VIVO")
2. **`data.json`** → snapshot estático (badge laranja "SNAPSHOT")
3. **`<script id="inline-data">`** dentro do HTML → último recurso (badge cinza "EMBUTIDO")

Você vê qual está ativo no canto superior direito do dashboard.

---

## 🚀 PASSO A PASSO — Ativar integração ao vivo com Notion

> Faça uma vez. Depois é tudo automático.

### Passo 1: Criar a Notion Integration

1. Acessa https://www.notion.so/profile/integrations
2. Clica em **"+ New integration"**
3. **Nome**: `Dashboard Apostas` (ou o que preferir)
4. **Associated workspace**: o workspace onde está a página `Apostas 2026`
5. **Type**: `Internal`
6. Clica em **Save**
7. Na tela seguinte, clica em **"Show"** ou **"Copy"** ao lado do **Internal Integration Secret**
   - Vai começar com `secret_...` ou `ntn_...`
   - **Copia esse valor inteiro** — você vai precisar no Passo 3

### Passo 2: Compartilhar as páginas com a integration

A integration NÃO tem acesso a nada por padrão. Você precisa autorizá-la em cada página/database:

1. Abre a página **`Apostas 2026`** no Notion
2. Clica no botão **`⋯`** (três pontinhos) no canto superior direito
3. Vai em **`+ Add connections`** (ou **`Connections`** dependendo da versão)
4. Procura pela integration que você criou (`Dashboard Apostas`)
5. Clica nela → confirma

✅ Como `Performance Mensal 2026`, `Unidades por Tipster` e os databases mensais (`Janeiro 2026`, `Fevereiro 2026`...) são **filhos** da página `Apostas 2026`, eles **herdam o acesso automaticamente**. Você não precisa adicionar a integration em cada um.

### Passo 3: Configurar o token no Netlify

1. Acessa o painel do Netlify → seu site
2. Vai em **Site configuration → Environment variables** (ou **Site settings → Environment variables** dependendo da versão)
3. Clica em **"Add a variable"** → **"Add a single variable"**
4. **Key**: `NOTION_TOKEN`
5. **Value**: cola aquele `secret_...` ou `ntn_...` que você copiou
6. **Scopes**: marca **"Functions"** (e pode marcar "Builds" também)
7. Salva

### Passo 4: Deploy (subir o código)

Arrasta a pasta `dashboard-mockup` inteira em https://app.netlify.com/drop (ou no painel "Deploys" do site existente).

⚠️ **Importante**: tem que ser a pasta **inteira** com o `netlify.toml` e `netlify/functions/` pra Netlify reconhecer e ativar a function.

### Passo 5: Verificar

1. Abre seu site → deve aparecer **"● AO VIVO"** no canto superior direito (badge verde)
2. Se aparecer "SNAPSHOT" (laranja) ou erro: abre o **Console do navegador** (F12) → procura mensagens em vermelho. Causas comuns:
   - Token errado/expirado → confere no Netlify
   - Integration não tem acesso à página → repete o Passo 2
   - Function não foi deployada → confere se o `netlify.toml` foi enviado

---

## 🛠️ Testar a function localmente (opcional)

Se quiser testar antes de subir:

```bash
# Instalar Netlify CLI (uma vez)
npm install -g netlify-cli

# Na pasta do projeto:
cd dashboard-mockup

# Cria um arquivo .env (NÃO commita isso)
echo "NOTION_TOKEN=secret_xxxxx" > .env

# Roda local
netlify dev
```

Vai abrir em `http://localhost:8888` e a function fica em `http://localhost:8888/.netlify/functions/notion-data`.

---

## 🔄 Atualização de dados

### Com integração ao vivo configurada

**Não precisa fazer nada**. Você atualiza no Notion → próximo F5 do site mostra atualizado (cache de ~60s no CDN do Netlify).

### Sem integração ao vivo (modo snapshot)

Me pede no Claude: **"atualiza dados do Notion"** → eu re-leio o Notion, regero `data.json` e o bloco `inline-data` do `index.html`. Você baixa e arrasta pro Netlify.

---

## ⚠️ Sobre a divergência de dados

No snapshot atual eu identifiquei:

| Tabela do Notion | Lucro total |
|---|---|
| `Performance Mensal 2026` | **+29,33u** |
| `Unidades por Tipster` (matriz) | **+79,50u** |

A página `Apostas 2026` mostra `Banca Atual = R$ 52.933,00` que coincide com **+29,33u**, então o dashboard usa **Performance Mensal como fonte de verdade pros KPIs**, e **Unidades por Tipster pra matriz/barras de tipster**.

A function ao vivo detecta a divergência automaticamente e mostra o aviso amarelo no dashboard.

**Recomendação**: confere no Notion qual das duas está desatualizada (provavelmente uma é manual).

---

## 🎨 Personalização

### Tema (cores e fontes)

Clica no botão **🎨 flutuante** no canto inferior direito do dashboard:
- **Cor de destaque**: 10 opções
- **Fundo**: 6 opções
- **Fontes**: corpo, título e KPIs (6 opções cada)
- **Salva no localStorage** — sua escolha persiste

### Default atual

- Cor: Laranja `#f97316`
- Fundo: Carvão `#1a1a1a`
- Título: Playfair Display
- Corpo + Números: Inter

Pra mudar o default permanente, edita o bloco `:root{}` no `<style>` do `index.html` e o `themeState` no JS.

### Banca / valor por unidade

- **Snapshot**: edita `data.json` → `config.bancaInicial` e `config.valorPorUnidade`
- **Ao vivo**: edita `netlify/functions/notion-data.js` → bloco `config: { ... }` perto do final

---

## 🔧 Filtros

| Filtro | Snapshot | Ao vivo |
|---|---|---|
| Período (chips + dropdown) | ✅ | ✅ |
| Tipster (multi-select) | ✅ | ✅ |
| Esporte | ❌ "soon" | ⚠️ requer expandir a function |
| Casa | ❌ "soon" | ⚠️ requer expandir a function |
| Live/Pré | ❌ "soon" | ⚠️ requer expandir a function |

> Os 3 últimos exigem ler todas as ~1.609 apostas individuais dos databases mensais (não só as 2 tabelas agregadas). Tecnicamente possível com a function ao vivo — me pede "**ativa filtros granulares**" depois que a integration estiver funcionando.

---

## ❓ FAQ

**Q: A function tá lenta (3+ segundos), o que faço?**
R: Notion API é meio lerda. Já configurei cache de 60s no CDN do Netlify (`Cache-Control: max-age=60`). O primeiro acesso é lento, os próximos 60s são instantâneos. Pra cache mais agressivo, edita o header em `notion-data.js` (linha `Cache-Control`).

**Q: Adicionei tipster novo no Notion mas não aparece no dashboard.**
R: Se for **ao vivo**, é só dar F5. Se for **snapshot**, você precisa atualizar (me pede). Se a cor dele tá cinza padrão, edita `TIPSTER_COLORS` em `notion-data.js` (ou `data.json` no snapshot).

**Q: Posso usar o mesmo NOTION_TOKEN em outros projetos?**
R: Sim, mas a integration só tem acesso às páginas que você compartilhou explicitamente com ela.

**Q: Como vejo logs da function (pra debugar erro)?**
R: No Netlify → **Functions** → clica em `notion-data` → vê os logs de invocação.

**Q: O custo aumenta se eu acessar muito?**
R: Netlify Free tier dá **125.000 invocações/mês** de function. Pra um dashboard pessoal você nem se aproxima. Se passar, são US$ 25 por mais 2 milhões. Pode ficar tranquilo.

---

## 🛠️ Stack

- **Frontend**: HTML/CSS/JS puro (zero build), Chart.js 4.4.1 via CDN
- **Backend**: Netlify Function (Node 18+ runtime nativo, sem dependências)
- **Dados**: Notion API v2022-06-28
- **Deploy**: Netlify Drop ou Git-connected
